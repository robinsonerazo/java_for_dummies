package com.inova.mostrarframetime;
import java.text.DecimalFormat;
        
public class JogadorPlus extends Jogador {
    
    private static int jogadorCont = 0;
    private static double totalDeMedias = .000; // maybe .dot. can be a problem...
    private static DecimalFormat decFormat = new DecimalFormat();
    
    static {
        decFormat.setMaximumIntegerDigits(0);
        decFormat.setMaximumFractionDigits(3);
        decFormat.setMinimumFractionDigits(3);
    }
    
    public JogadorPlus(String nome, double media) {
        super(nome, media);
        jogadorCont++;
        totalDeMedias += media;
    }
    
    public static double calcMediaTime() {
        return totalDeMedias / jogadorCont;
    }
    
    public static String calcMediaTimeString() {
        return decFormat.format(totalDeMedias / jogadorCont);
    }
}
