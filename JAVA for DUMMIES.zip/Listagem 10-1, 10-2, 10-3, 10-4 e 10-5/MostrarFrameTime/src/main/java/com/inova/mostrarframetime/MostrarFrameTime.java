package com.inova.mostrarframetime;
import java.io.IOException;

class MostrarFrameTime {

    public static void main(String[] args) throws IOException {
        //new FrameTime();
        new FrameTimePlus();
    }
}