package com.mycompany.nadadesoneca;

import static java.lang.System.out;

class NadaDeSoneca {

    public static void main(String[] args) {
        out.print("Com licença, vou tirar ");
        out.println("Uma soneca por cinco segundos...");
        
        tirarUmaSoneca();
        out.println("Ah, que revigorante.");
    }
    
    static void tirarUmaSoneca() {
        Thread.sleep(5000);
    }
}
