package com.mycompany.bomsonhosa;

import static java.lang.System.out;

public class BomSonhosA {

    public static void main(String[] args) {
        out.print("Com licença vou tirar ");
        out.println("uma soneca por cinco segundos...");
        
        tirarUmaSoneca();
        
        out.println("Ah, que revigorante.");
    }
    
    static void tirarUmaSoneca () {
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            out.println("Ei, quem me acordou?");
        }
    }
}
