/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.inova.alsallwet;
import static java.lang.System.out;
        
class AlsAllWet {

    public static void main(String[] args) {
        
        for(int verso = 1; verso <= 3; verso++) {
            out.print("Al's all wet. ");
            out.println("Oh, why is All all wet? Oh,");
            out.print("Al's all wet `cause ");
            out.println("he's standing in the rain.");
            out.println("Why is Al out in the rain?");
            
            switch (verso) {
                case 1:
                    out.println("That's because he has no brain.");
                    break;
                
                case 2:
                    out.println("That's because he is a pain.");
                    break;
                    
                case 3:
                    out.println("`Cause this is the last refrain.");
                    break;
            }
            
            switch (verso) {
                case 3:
                    out.println("Last refrain, last refrain, ");
                
                case 2:
                    out.println("He's a pain, he's a pain,");
                    
                case 1:
                    out.println("Has no brain, has no brain,");
            }
            
            out.println("In the rain, in the rain.");
            out.println("Ohhhh...");
            out.println();
        }
        
        out.print("Al's all wet. ");
        out.println("Oh, why is Al all wet? Oh, ");
        out.print("Al's all wet `cause ");
        out.println("he's standing in the rain.");
    }
}
