/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.inova.mostreumframe;
import javax.swing.JFrame;
        
/**
 *
 * @author Inova
 */

class MostreUmFrame {

    public static void main(String args []) {
        JFrame meuFrame = new JFrame();
        String meuTitulo = "Frame em Branco";
        
        meuFrame.setTitle(meuTitulo);
        meuFrame.setSize(300, 300);
        meuFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        meuFrame.setVisible(true);
    }
}
