/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.inova.usodaconta;

/**
 *
 * @author Inova
 */
public class Conta {
    private String nome;
    private String endereco;
    private double saldo;
    
    public void setNome(String n){
        if (!n.equals("")) {
            nome = n;
        }
        
    }
    
    public String getNome() {
        return nome;
    }
    
    public void setEndereco(String e) {
        endereco = e;
    }
    
    public String getEndereco() {
        return endereco;
    }
    
    public void setSaldo(double s) {
        saldo = s;
    }
    
    public double getSaldo() {
        return saldo;
    }
}
