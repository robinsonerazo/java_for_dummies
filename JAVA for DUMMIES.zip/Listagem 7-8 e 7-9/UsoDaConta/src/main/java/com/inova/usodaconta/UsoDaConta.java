/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.inova.usodaconta;
import static java.lang.System.out;

/**
 *
 * @author Inova
 */
 
class UsoDaConta {

    public static void main(String[] args) {
        Conta minhaConta = new Conta();
        Conta suaConta = new Conta();
        
        
        minhaConta.setNome("Barry");
        minhaConta.setEndereco("Rua Cyberespaço 222");
        minhaConta.setSaldo(24.02);
        
        suaConta.setNome("João Q. Público");
        suaConta.setEndereco("Rua do Consumidor 111");
        suaConta.setSaldo(55.63);
        
        out.print(minhaConta.getNome());
        out.print(" (");
        out.print(minhaConta.getEndereco());
        out.print(") tem $");
        out.print(minhaConta.getSaldo());
        out.println();
        
        out.print(suaConta.getNome());
        out.print(" (");
        out.print(suaConta.getEndereco());
        out.print(") tem $");
        out.print(suaConta.getSaldo());
        out.println();
    }
}
