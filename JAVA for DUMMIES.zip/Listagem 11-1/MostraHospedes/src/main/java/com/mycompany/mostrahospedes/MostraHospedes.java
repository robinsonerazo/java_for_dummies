package com.mycompany.mostrahospedes;
import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;
import java.io.IOException;

class MostraHospedes {

    public static void main(String[] args) throws IOException {
        
        int hospedes[] = new int[10];
        Scanner diskScanner;
        diskScanner = new Scanner(new File("ListaHospedes.txt"));
        
        for(int numQuarto = 0; numQuarto < 10 ; numQuarto++) {
            hospedes[numQuarto] = diskScanner.nextInt(); 
        }
        
        out.println("Quarto\tHóspedes");
        
        for(int numQuarto = 0; numQuarto < 10 ; numQuarto++) {
            out.print(numQuarto);
            out.print("\t");
            out.println(hospedes[numQuarto]);
        }
    }
}
