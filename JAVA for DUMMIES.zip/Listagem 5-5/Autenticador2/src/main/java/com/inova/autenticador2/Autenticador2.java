/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.inova.autenticador2;
import static java.lang.System.out;
import java.util.Scanner;

/**
 *
 * @author Inova
 */
class Autenticador2 {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        
        out.print("Username: ");
        String username = keyboard.next();
        
        if (username.equals("bburd")) {
            out.print("Password: ");
            String password = keyboard.next();
            
            if (password.equals("swordfish")) {
                out.println("Você está conectado.");
            } else {
                out.println("Senha incorreta");
            }
        } else {
            out.println("Usuário desconhecido");
        }
    }
}
