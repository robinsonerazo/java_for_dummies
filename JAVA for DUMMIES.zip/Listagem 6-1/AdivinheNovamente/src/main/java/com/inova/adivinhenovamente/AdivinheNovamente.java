package com.inova.adivinhenovamente;

import static java.lang.System.out;
import java.util.Scanner;
import java.util.Random;

class AdivinheNovamente {

    public static void main(String args[]) {
        Scanner keyboard = new Scanner(System.in);
        
        int numPalpites = 0;
        int numeroAleatorio = new Random().nextInt(10) + 1;
        
        out.println("  *******  ");
        out.println("Bem vindo ao Jogo de Adivinhação");
        out.println("  *******  ");
        out.println();
        
        out.print("Insira um número de 1 a 10:");
        int numeroEntrada = keyboard.nextInt();
        numPalpites++;
        
        while (numeroEntrada != numeroAleatorio) {
            out.println();
            out.println("Tente novamente...");
            out.print("Insira um número de 1 a 10: ");
            numeroEntrada = keyboard.nextInt();
            numPalpites++;
        }
        
        out.print("Você ganhou depois de ");
        out.println(numPalpites + " tentativas.");
    }
}
