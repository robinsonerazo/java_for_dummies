/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.inova.milionario;

/**
 *
 * @author Inova
 */
class Milionario {

    public static void main(String[] args) {
        double valorNaConta;
        
        valorNaConta = 50.22;
        valorNaConta = valorNaConta + 1000000.00;
        
        System.out.print("Você tem R$");
        System.out.print(valorNaConta);
        System.out.println(" em sua conta.");
    }
}
