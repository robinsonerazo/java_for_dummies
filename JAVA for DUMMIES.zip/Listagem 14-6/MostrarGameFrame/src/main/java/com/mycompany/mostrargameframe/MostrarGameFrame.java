package com.mycompany.mostrargameframe;

/**
 *
 * Classes Internas Anônimas
 *
 */

class MostrarGameFrame {

    public static void main(String[] args) {
        new GameFrame();
    }
}
