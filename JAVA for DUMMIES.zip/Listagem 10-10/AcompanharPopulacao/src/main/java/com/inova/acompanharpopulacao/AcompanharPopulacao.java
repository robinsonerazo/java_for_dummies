package com.inova.acompanharpopulacao;

class AcompanharPopulacao {

    public static void main(String[] args) {
        int popMontLobSP = 4123;
        
        nascimento(popMontLobSP);
        System.out.println(popMontLobSP);
    }
    
    static void nascimento(int popCidade) {
        popCidade++;
    }
}