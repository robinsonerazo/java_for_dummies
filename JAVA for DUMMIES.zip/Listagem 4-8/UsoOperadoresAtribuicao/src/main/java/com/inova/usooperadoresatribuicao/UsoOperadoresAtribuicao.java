/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.inova.usooperadoresatribuicao;

/**
 *
 * @author Inova
 */
class UsoOperadoresAtribuicao {

    public static void main(String[] args) {
        int numeroDeCoelhos = 27;
        int numeroExtra = 53;
        
        numeroDeCoelhos += 1;
        System.out.println(numeroDeCoelhos);
        
        numeroDeCoelhos += 5;
        System.out.println(numeroDeCoelhos);
        
        numeroDeCoelhos += numeroExtra;
        System.out.println(numeroDeCoelhos);
        
        numeroDeCoelhos *= 2;
        System.out.println(numeroDeCoelhos);
        
        System.out.println(numeroDeCoelhos -= 7);
        System.out.println(numeroDeCoelhos = 100);
    }
}
