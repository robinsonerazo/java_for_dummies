package com.inova.usodaconta;
import static java.lang.System.out;

public class UsoDaConta {

    public static void main(String[] args) {
        Conta minhaConta = new Conta();
        Conta suaConta   = new Conta();
        
        minhaConta.setNome("Barry Burd");
        minhaConta.setEndereco("Rua dos Eucaliptos 222");
        minhaConta.setSaldo(24.02);
        
        suaConta.setNome("Warren Buffet");
        suaConta.setEndereco("Rua dos Colibris 1000");
        suaConta.setSaldo(55.63);
        
        out.print(minhaConta.getNome());
        out.print(" (");
        out.print(minhaConta.getEndereco());
        out.print(") tem $");
        out.print(minhaConta.getSaldo());
        out.println();
        
        out.print(suaConta.getNome());
        out.print(" (");
        out.print(suaConta.getEndereco());
        out.print(") tem $");
        out.print(suaConta.getSaldo());
    }
}
