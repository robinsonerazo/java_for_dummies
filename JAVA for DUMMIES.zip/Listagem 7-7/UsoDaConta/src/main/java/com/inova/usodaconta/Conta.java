package com.inova.usodaconta;

public class Conta {

// Atributos ---------------------------------------------------------------
    
    private String nome;
    private String endereco;
    private double saldo;

// Métodos -----------------------------------------------------------------

    public void setNome(String n) {
        if (!n.equals("")) {
            nome = n;
        }
    }
    
    public String getNome() {
        return nome;
    }
    
    public void setEndereco(String e) {
        endereco = e;
    }
    
    public String getEndereco() {
        return endereco;
    }
    
    public void setSaldo(double s) {
        saldo = s;
    }
    
    public double getSaldo() {
        return saldo;
    }
}
