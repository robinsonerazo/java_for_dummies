package com.mycompany.inventariod;

@SuppressWarnings("serial")
class ExcecaoNumeroMuitoGrande extends ExcecaoForaDoPadrao {    
    
}
