package com.mycompany.inventariod;

@SuppressWarnings("serial")
class ExcecaoForaDoPadrao extends Exception {
    
}
