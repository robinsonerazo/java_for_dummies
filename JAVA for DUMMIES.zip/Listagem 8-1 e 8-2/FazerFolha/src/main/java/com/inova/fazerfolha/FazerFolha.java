package com.inova.fazerfolha;

import java.util.Scanner;
import java.io.File;
import java.io.IOException;

public class FazerFolha {
    
    public static void main(String[] args) throws IOException {
        File bff = new File("EmpregadosInfo.txt");    
        
        System.out.println(bff.exists());
        System.out.println(bff.getAbsolutePath());
        System.out.println(bff.getParent());
        System.out.println(bff.canRead());
        
        Scanner diskScanner = new Scanner(bff);
            
            for (int empNum = 1; empNum <= 3; empNum++) {
                pagarUmEmpregado(diskScanner);
            }    
        }
    
        static void pagarUmEmpregado(Scanner aScanner) {
            Empregado umEmpregado = new Empregado();
            umEmpregado.setNome(aScanner.nextLine());
            umEmpregado.setCargo(aScanner.nextLine());
            umEmpregado.preencherCheque(Double.parseDouble(aScanner.nextLine()));
        }
}