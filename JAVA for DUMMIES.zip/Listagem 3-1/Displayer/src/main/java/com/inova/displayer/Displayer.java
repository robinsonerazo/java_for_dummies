/*
 * Listing 3-1 em "Java para Leigos, Tradução da 5ª Edição"
 *
 * Copyright 2013 Editora Alta Books
 * Todos os direitos reservados.
 */



/**
 * A class Displayer mostra  o texto
 * na tela do computador
 * 
 * @author Inova
 * @version 1.0 15/08/2022
 * @see java.lang.System
 */


package com.inova.displayer;

public class Displayer {
    
    /**
     * O método main é onde
     * a execução do código começa.
     * 
     * @param args (veja Capítulo 11) 
     */

    public static void main(String[] args) {
        System.out.println("You'll love Java!"); // Eu? Você?
    }
}
