package com.inova.acompanharpopulacao3;

public class Cidade {
    int populacao;
}
