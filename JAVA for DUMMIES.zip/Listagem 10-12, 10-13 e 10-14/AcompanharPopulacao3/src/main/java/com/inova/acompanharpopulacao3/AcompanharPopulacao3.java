package com.inova.acompanharpopulacao3;

//class AcompanharPopulacao3 {
//
//    public static void main(String[] args) {
//       Cidade MontLobSP = new Cidade();
//       MontLobSP.populacao = 4123;
//       nascimento(MontLobSP);
//       System.out.println(MontLobSP.populacao);
//    }
//    
//    static void nascimento(Cidade aCidade) {
//        aCidade.populacao++;
//    }
//}


class AcompanharPopulacao3 {

    public static void main(String[] args) {
       Cidade MontLobSP = new Cidade();
       MontLobSP.populacao = 4123;
       MontLobSP = doNascimento(MontLobSP);
       System.out.println(MontLobSP.populacao);
    }
    
    static Cidade doNascimento(Cidade aCidade) {
        Cidade minhaCidade = new Cidade();
        minhaCidade.populacao = aCidade.populacao + 1;
        return minhaCidade;
    }
}