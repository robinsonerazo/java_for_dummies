package com.mycompany.mostrarmoneyframe;

/**
 *
 * @author robinson
 */
public class MostrarMoneyFrame {

    public static void main(String[] args) {
        new MoneyFrame();
    }
}
