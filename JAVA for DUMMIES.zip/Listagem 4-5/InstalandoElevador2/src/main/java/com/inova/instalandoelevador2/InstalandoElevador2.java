/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.inova.instalandoelevador2;

/**
 *
 * @author Inova
 */
class InstalandoElevador2 {

    public static void main(String[] args) {
        System.out.println("Verdadeiro ou Falso?");
        System.out.println("Você pode colocar o dez");
        System.out.println("Jurados do concurso");
        System.out.println("no elevador:");
        System.out.println();
        
        int pesoDeUmaPessoa = 68;
        int limiteDePesoElevador = 630;
        int numeroDePessoas = limiteDePesoElevador / pesoDeUmaPessoa;
        
        boolean todosDezOK = numeroDePessoas >= 10;
        
        System.out.println(todosDezOK);
    }
}
