package com.mycompany.mostrahospedes;
import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;
import java.io.IOException;

class MostraHospedes {

    public static void main(String[] args) throws IOException {
        
        int hospedes[] = {1, 2+2, 2, 0, 2, 1, 4, 3, 0, 2};
        
        out.println("Quarto\tHóspedes");
        
        for(int numQuarto = 0; numQuarto < 10 ; numQuarto++) {
            out.print(numQuarto);
            out.print("\t");
            out.println(hospedes[numQuarto]);
        }
    }
}
