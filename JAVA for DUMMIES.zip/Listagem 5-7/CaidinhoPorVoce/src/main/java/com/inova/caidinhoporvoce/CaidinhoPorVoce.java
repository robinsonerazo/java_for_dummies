/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.inova.caidinhoporvoce;
import static java.lang.System.out;
import java.util.Scanner;

/**
 *
 * @author Inova
 */

class CaidinhoPorVoce {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        out.print("Qual o verso?");
        int verso = keyboard.nextInt();
        
        switch (verso) {
            case 3: 
                out.print("Last refrain,");
                out.println("last refrain,");
            case 2:
                out.print("He's a pain,");
                out.println("he's a pain,");
            case 1:
                out.print("Has no brain,");
                out.println("has no brain,");
        }
            out.println("In the rain, in the rain.");
            out.println("Ohhhhhhhh...");
            out.println();
    }
}
