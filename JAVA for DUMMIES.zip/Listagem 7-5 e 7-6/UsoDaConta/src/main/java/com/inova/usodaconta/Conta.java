package com.inova.usodaconta;
import static java.lang.System.out;

public class Conta {

//Atributos
    
    String nome;
    String endereco;
    double saldo;

//Métodos

    public void display() {
        out.print(nome);
        out.print(" (");
        out.print(endereco);
        out.print(") tem $");
        out.print(saldo);
    }
    
    public double getJuros(double taxaPercentual){
        return saldo*taxaPercentual/100.00;
    }
}
