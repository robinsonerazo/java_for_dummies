package com.inova.usodaconta;
import static java.lang.System.out;

public class UsoDaConta {

    public static void main(String[] args) {
        Conta minhaConta = new Conta();
        Conta suaConta = new Conta();
        
        minhaConta.nome = "Barry Burd";
        minhaConta.endereco = "Rua dos Eucaliptos 222";
        minhaConta.saldo = 24.02;
        
        suaConta.nome = "Warren Buffet";
        suaConta.endereco = "Rua dos Colibris 1000";
        suaConta.saldo = 55.63;
        
        minhaConta.display();
        
        out.print(" mais $");
        out.print(minhaConta.getJuros(5.00));
        out.println(" juros ");
        
        suaConta.display();
        
        double suaTaxaJuros = 7.00;
        out.print(" mais $");
        double seuValorJuros = suaConta.getJuros(suaTaxaJuros);
        out.print(seuValorJuros);
        out.println(" juros ");
    }
}
