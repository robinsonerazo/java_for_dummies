package com.inova.usartemperatura;

public enum EscalaTemp {
    CELSIUS, FAHRENHEIT, KELVIN, RANKINE, 
    NEWTON, DELISLE, RÉAUMUR,RØMER, LEIDEN
};
