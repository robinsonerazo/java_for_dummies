package com.inova.usartemperatura;
import static java.lang.System.out;
        
class UsarTemperatura {

    public static void main(String[] args) {
        
        final String format = "%5.2f graus %s\n";
        
        //String format = "%6.2f graus %s\n";
        
        Temperatura temp = new Temperatura();
        temp.setNumero(70.0);
        temp.setEscala(EscalaTemp.FAHRENHEIT);
        out.printf(format, temp.getNumero(), temp.getEscala());
        
        temp = new Temperatura(32.0);
        out.printf(format, temp.getNumero(), temp.getEscala());
        
        temp = new Temperatura(EscalaTemp.CELSIUS);
        out.printf(format, temp.getNumero(), temp.getEscala());
        
        temp = new Temperatura(2.73, EscalaTemp.KELVIN);
        out.printf(format, temp.getNumero(), temp.getEscala());
        
        // Enum & Switch example
        EscalaTemp escala = EscalaTemp.RANKINE;
        
        char letter;
        
        switch (escala) {
            case CELSIUS:
                letter = 'C';
                break;
            case KELVIN:
                letter = 'K';
                break;
            case RANKINE:
            case RÉAUMUR:
            case RØMER:
                letter = 'R';
                break;
            default:
                letter = 'X';
                break;
        }
        
    }
}
