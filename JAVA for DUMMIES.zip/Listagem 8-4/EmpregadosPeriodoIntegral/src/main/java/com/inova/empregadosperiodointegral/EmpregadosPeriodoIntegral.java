package com.inova.empregadosperiodointegral;

import static java.lang.System.out;

public class EmpregadosPeriodoIntegral {

    //***************** Atributos **********************************************
    
    private String nome;
    private String cargo;
    private double salarioSemanal;
    private double deducaoBeneficios;
    
    
    // ****************  Métodos ***********************************************
    
    public void setNome(String nomeIn) {
        nome = nomeIn;
    }
    
    public String getNome() {
        return nome;
    }
    
    public void setCargo(String cargoIn) {
        cargo = cargoIn;
    }
    
    public String getCargo() {
        return cargo;
    }
    
    public void setSalarioSemanal(double salarioSemanalIn) {
        salarioSemanal = salarioSemanalIn;
    }
    
    public double getSalarioSemanal() {
        return salarioSemanal;
    }
    
    public void setDeducaoBeneficios(double benefDedIn){
        deducaoBeneficios = benefDedIn;
    }
    
    public double getDeducaoBeneficios() {
        return deducaoBeneficios;
    }
    
    public double calcValorPagamento() {
        return salarioSemanal - deducaoBeneficios;
    }
    
    public void preencherCheque(double valorPago){
        out.printf("Pagar para %s ", nome);
        out.printf("(%s) ***$", cargo);
        out.printf("%,.2f\n", valorPago);        
    }
    
    
    
    
    
// -------------------------- MAIN ------------------------------------    
       
    public static void main(String[] args) {
        EmpregadosPeriodoIntegral Jose = new EmpregadosPeriodoIntegral(); 
        Jose.setNome("José Simão");  
        Jose.setCargo("Pedreiro");     
        
        out.println(Jose.getNome());
        out.println(Jose.getCargo());
        
        Jose.preencherCheque(1000.00);
    }
}
