package com.mycompany.mostrarframe;

import com.mycompany.drawings.Drawing; //Dispensável no caso de DrawingWide
import com.mycompany.frames.ArtFrame;
import com.mycompany.drawings.DrawingWideBB;

public class MostrarFrame {

    public static void main(String[] args) {
        //ArtFrame artFrame = new ArtFrame(new Drawing());
        //ArtFrame artFrame = new ArtFrame(new DrawingWide());
        ArtFrame artFrame = new ArtFrame(new DrawingWideBB());

        
        artFrame.setSize(200, 100);
        artFrame.setVisible(true);
    }
}
