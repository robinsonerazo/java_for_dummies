package com.mycompany.inventarioc;

@SuppressWarnings("serial")
class ExcecaoForaDoPadrao extends Exception {
    
}
