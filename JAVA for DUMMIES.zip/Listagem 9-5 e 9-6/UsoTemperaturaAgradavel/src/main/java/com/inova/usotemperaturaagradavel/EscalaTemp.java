package com.inova.usotemperaturaagradavel;

public enum EscalaTemp {
    CELSIUS, FAHRENHEIT, KELVIN, RANKINE, 
    NEWTON, DELISLE, RÉAUMUR,RØMER, LEIDEN
};