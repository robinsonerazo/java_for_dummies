package com.mycompany.bomsonhosb;

import static java.lang.System.out;

class BomSonhosB {

    public static void main(String[] args) {
        out.print("Com licença vou tirar ");
        out.println("uma soneca por cinco segundos...");
        
        try {
            tirarUmaSoneca();
        } catch (InterruptedException e) {
            out.println("Ei, quem me acordou?");
        }
        
        out.println("Ah, que revigorante.");
    }
    
    static void tirarUmaSoneca () throws InterruptedException {
        Thread.sleep(5000);
    }   
}

