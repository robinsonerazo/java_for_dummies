/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.inova.instaladorelevador;

/**
 *
 * @author Inova
 */
class InstaladorElevador {

    public static void main(String[] args) {
        //int pesoDeUmaPessoa, limiteDePesoElevador, numeroDePessoas;
        int pesoDeUmaPessoa = 68, limiteDePesoElevador = 630, numeroDePessoas = limiteDePesoElevador / pesoDeUmaPessoa;
        
        System.out.print("Cabem ");
        System.out.print(numeroDePessoas);
        System.out.println(" pessoas no elevador.");
    }
}
