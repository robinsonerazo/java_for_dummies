package com.inova.vamos;
import static java.lang.System.out;

public class Vamos {

    public static void main(String[] args) {
        out.println("main em andamento:");
        FalantesDePortugues p = new FalantesDePortugues();
        //out.println(marte);
        out.println(p.marte);
        p.visiteMinasGerais();
    }
}
