package com.inova.vamos;

import static java.lang.System.out;

public class FalantesDePortugues {
    String marte = " planeta vermelho";
    
    void visiteMinasGerais() {
        out.println("visiteMG está em andamento:");
        String marte = " cidade natal de Janine";
        out.println(marte);
        out.println(this.marte);
    }
}
