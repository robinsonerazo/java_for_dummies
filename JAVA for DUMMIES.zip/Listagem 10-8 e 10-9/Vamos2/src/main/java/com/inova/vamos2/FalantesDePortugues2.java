package com.inova.vamos2;
import static java.lang.System.out;

class FalantesDePortugues2 {
    String marte;
    
    void visiteSantaCatarina() {
        out.println("visiteSC está em execução:");
        
        marte = " planeta vermelho";
        String riqueza = " População: 25";
        out.println(marte);
        out.println(riqueza);
    }
    
    void visiteSaoPaulo() {
        out.println("visiteSP está em execução:");
        out.println(marte);
        //out.println(riqueza);
        // cannot resolve symbol
    }
}
