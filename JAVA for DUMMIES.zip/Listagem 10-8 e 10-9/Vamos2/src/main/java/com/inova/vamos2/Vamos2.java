package com.inova.vamos2;

public class Vamos2 {

    public static void main(String[] args) {
        FalantesDePortugues2 p = new FalantesDePortugues2();
        p.visiteSantaCatarina();
        p.visiteSaoPaulo();
    }
}


//Terminar de fazer!