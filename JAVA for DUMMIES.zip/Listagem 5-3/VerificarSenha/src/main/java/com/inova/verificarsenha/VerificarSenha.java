/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.inova.verificarsenha;
import static java.lang.System.*;
import java.util.Scanner;

/**
 *
 * @author Inova
 */
class VerificarSenha {

    public static void main(String[] args) {
        
        out.print("Qual a senha?");
        
        Scanner keyboard = new Scanner(in);
        String senha = keyboard.next();
        
        out.println("Você digitou >>" + senha + "<<");
        out.println();
        
        if (senha == "swordfish") {
            out.println("A palavra digitada está gravada");
            out.println("no mesmo lugar que a verdadeira");
            out.println("senha. Você tem que ser");
            out.print("hacker.");
        } else {
            out.println("A palavra digitada não está");
            out.println("gravada no mesmo lugar que a");
            out.println("senha verdadeira, mas não tem");
            out.print("problema.");        
        }
        
        out.println();
        out.println();
        
        if (senha.equals("swordfish")) {
            out.println("A palavra digitada tem");
            out.println("os mesmos caracteres que a");
            out.println("senha real. Pode usar o");
            out.println("sistema.");
        } else {
            out.println("A palavra digitada não");
            out.println("tem os mesmos caracteres");
            out.println("que a senha real. Não pode");
            out.println("usa o sistema.");        
        }                  
    }
}
