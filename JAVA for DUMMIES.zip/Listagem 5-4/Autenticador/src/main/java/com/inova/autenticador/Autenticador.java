/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.inova.autenticador;
import javax.swing.JOptionPane;

/**
 *
 * @author Inova
 */

class Autenticador {

    public static void main(String[] args) {
        
        String username = JOptionPane.showInputDialog("Nome do " + " Usuario:");
        String password = JOptionPane.showInputDialog("senha:");
        
        if (
            username != null && 
            password != null &&
                (
                    (username.equals("bburd") &&
                    password.equals("swordfish")) ||
                    (username.equals("hhitter") &&
                    password.equals("preakston"))
                )    
            )
        {
            JOptionPane.showMessageDialog(null, "Você está conectado.");
        } else {
            JOptionPane.showMessageDialog(null, "Você é suspeito.");
        }
    }
}
