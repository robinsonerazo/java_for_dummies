/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.inova.troco;
import static java.lang.System.out;

/**
 *
 * @author Inova
 */

class Troco {

    public static void main(String[] args) {
        int total = 248;
        int quartos = total/25;
        int oqueSobra = total % 25;
        
        int dezcentavos = oqueSobra / 10;
        oqueSobra = oqueSobra % 10;
        
        int cincocentavos = oqueSobra / 5;
        oqueSobra = oqueSobra % 5;
        
        int centavos = oqueSobra;
        
        out.println("De " + total + " centavos obtidos");
        out.println(quartos + " quartos");
        out.println(dezcentavos + " dez centavos");
        out.println(cincocentavos + " cinco centavos");
        out.println(centavos + " centavos");
    }
}
