package com.mycompany.simpleapplet;

import javax.swing.JApplet;

/**
 *
 * @author robinson
 */

public class SimpleApplet extends JApplet {
    private static final long serialVersionUID = 1L;
    
    public void init() {
        setContentPane(new PainelParaLeigos());
    }
}
