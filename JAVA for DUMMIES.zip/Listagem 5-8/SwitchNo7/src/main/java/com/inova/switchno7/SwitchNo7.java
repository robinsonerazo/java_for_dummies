/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.inova.switchno7;
import static java.lang.System.out;
import java.util.Scanner;

/**
 *
 * @author Inova
 */
class SwitchNo7 {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        out.print("Qual o verso [um, dois ou três]?");
        String verso = keyboard.next();
        
        switch (verso) {
            case "um":
                out.println("That's because he has no brain.");
                break;
            case "dois":
                out.println("That's because he is a pain.");
                break;
            case "três":
                out.println("Cause this is the last refrain.");
                break;
            default:
                out.println("Não há este verso. Por favor tente novamente.");
                break;
                
        }
        out.println("Ohhhhh...");
    }
}
