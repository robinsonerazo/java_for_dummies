/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.inova.jogodeadivinhacao;
import static java.lang.System.out;
import java.util.Scanner;
import java.util.Random;        

/**
 *
 * @author Inova
 */

class JogoDeAdivinhacao {

    public static void main(String[] args) {
        Scanner teclado;
        teclado = new Scanner(System.in);
        
        
        out.print("Entre com um int de 1 a 10: ");
        
        int numeroEntrada = teclado.nextInt();
        int numeroAleatorio = new Random().nextInt(10) + 1;
        
        if (numeroEntrada == numeroAleatorio) {
            out.println("**********");
            out.println("*Você vence.*");
            out.println("**********");
        } else {
            out.println("Você perde.");
            out.print("O número aleatório era ");
            out.println(numeroAleatorio + ".");
        }
        out.println("Obrigado por jogar.");
    }
}
