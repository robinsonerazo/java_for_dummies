package com.inova.usodeconta;

import static java.lang.System.out;

class UsoDeConta {

    public static void main(String[] args) {
        Conta minhaConta = new Conta();
        Conta suaConta = new Conta();  
              
        minhaConta.nome = "Barry Burd";
        minhaConta.endereco = "Rua Ciberespaço 222";
        minhaConta.saldo = 24.02;
        
        suaConta.nome = "Zé Ninguém";
        suaConta.endereco = "Rua dos Bobos 000";
        suaConta.saldo = 55.63;
        
        out.print(minhaConta.nome);
        out.print(" (");
        out.print(minhaConta.endereco);
        out.print(") tem $");
        out.print(minhaConta.saldo);
        out.println();
        
        out.print(suaConta.nome);
        out.print(" (");
        out.print(suaConta.endereco);
        out.print(") tem $");
        out.print(suaConta.saldo);
    }
}
