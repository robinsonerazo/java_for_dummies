package com.inova.usodeconta;

public class Conta {
    String nome;
    String endereco;
    double saldo;
}
