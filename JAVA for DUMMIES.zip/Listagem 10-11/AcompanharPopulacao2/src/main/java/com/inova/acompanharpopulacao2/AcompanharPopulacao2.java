package com.inova.acompanharpopulacao2;

class AcompanharPopulacao2 {

    public static void main(String[] args) {
        int popMontLobSP = 4123;
        
        popMontLobSP = nascimento(popMontLobSP);
        System.out.println(popMontLobSP);
    }
    
    static int nascimento(int popCidade) {
        return ++popCidade; // adiciona ANTES de retornar, se popCidade++ não retorna
    }
}