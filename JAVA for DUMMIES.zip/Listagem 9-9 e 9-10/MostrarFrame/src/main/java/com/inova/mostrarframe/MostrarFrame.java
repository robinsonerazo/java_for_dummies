package com.inova.mostrarframe;

class MostrarFrame {

    public static void main(String[] args) {
        new SimpleFrame();
    }
}
