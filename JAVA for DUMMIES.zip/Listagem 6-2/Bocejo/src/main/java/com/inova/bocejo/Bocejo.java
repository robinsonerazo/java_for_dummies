package com.inova.bocejo;
import static java.lang.System.out;

class Bocejo {

    public static void main(String[] args) {
        
        for (int count = 1; count <= 10; count++) {
            out.print("O valor da contagem é ");
            out.print(count);
            out.println(".");
        }
        
        out.print("Pronto!");
    }
}
