package com.mycompany.drawings;

import com.mycompany.frames.ArtFrame;
/**
 *
 * @author robinson
 */
public class MostrarFrameWideBB {
    public static void main(String args[]){
        Drawing drawing = new Drawing();
        drawing.width = 100;
        drawing.height = 30;
        
        ArtFrame artFrame = new ArtFrame(drawing);
        artFrame.setSize(200, 100);
        artFrame.setVisible(true);
    } 
}
