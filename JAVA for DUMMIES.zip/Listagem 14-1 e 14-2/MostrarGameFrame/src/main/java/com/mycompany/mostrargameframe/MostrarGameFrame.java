package com.mycompany.mostrargameframe;

/**
 *
 * @author robinson
 */
class MostrarGameFrame {

    public static void main(String[] args) {
        new GameFrame();
    }
}
